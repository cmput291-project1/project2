
public class Pref{
	private static int dbType;
	
	public static void setDbType(int type){
		dbType = type;
	}

	public static int getDbType(){
		return dbType;
	}
}
